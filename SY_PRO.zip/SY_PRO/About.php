<html>
    <body>
         <table border="1" width="90%" align="center">
              <tr>
                <td>
                     <p align='center'> Rayat Shikshan Sanstha's </p>
                    <h1 align="center"> C.D.Jain College of Commerce Shrirampur </h1>
                     <h3> Address: Shrirampur MH.413709.  Phone: 0987654321
                </td>
             </tr>
         </table>
         <table border="1" width="90%" align="center">
              <tr>
                <td> <a href='Index.php'>Home </a> 
                <td> <a href='About.php'>About </a> 
                <td> <a href='Dept.php'>Dept </a> 
                <td> <a href='Syllabous.php'>Syllabous </a> 
                <td> <a href='Sports.php'>Sports </a> 
                <td> <a href='Account.php'>Account Dept </a> 
                <td> <a href='Library.php'>Library </a> 
                <td> <a href='Contact.php'>Contact Us</a> 
               </tr>
         </table>
         <table border="1" width="90%"  height="70%" align="center">
              <tr>
                    <td width="20%" valign="top"> 
                          Photo <br>
                            <img width="100%"  src="images/logo1.jpg"> <br>
                          Rayat Shikshan Sanstha's � CHANDRAROOP DAKLE JAIN COLLEGE OF COMMERCE SHRIRAMPUR, DIST : AHMEDNAGAR � Established Year : 1962 � Affiliated to Savitribai Phule Univ..
                                       
                    <td width="60%" valign="top" bgcolor="yellow"> 
                         <h1> This is About Page
              
      <td width="20%" valign="top"> 
                        <h1> Notice </h1>
                 <marquee direction="up"> 
                       <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice...  
                 </marquee>
              </tr>
         </table>
       <table border="1" width="90%"  bgcolor="gray" height="20%" align="center">
              <tr>
                <td>
                   <h2> Copyright@cdjcollege2023 </h2>
<pre>
Alumni
Introduction
Goal & Objectives
Alumni Membership Form
Alumni Committee
List Of Alumni
Student Login
</pre>
             </tr>
         </table>
               
   </body>
</html>