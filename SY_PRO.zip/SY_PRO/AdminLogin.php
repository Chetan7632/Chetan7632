<?php
    $u=$_POST["t1"];
    $p=$_POST["t2"];
    if($u=="cdj"&&$p=="1234")
      header('location:Admin.php');
    else
      echo("<h1> Invalid User or pass <a href='Index.php'> BACK </a>");
?>