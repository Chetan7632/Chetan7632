<?php
    $name=$_POST["t1"];
    $add=$_POST["t2"];
    $ph=$_POST["t3"];
    $cl=$_POST["t4"];
    $per=$_POST["t5"];
	$pho=$_POST["t6"];
	$u=$_POST["t7"];
	$p=$_POST["t8"];
	
     $con=mysql_connect("localhost","root","");
     if($con==false) 
         die("Error in connection...");
     mysql_select_db("sypro");
    
    $res=mysql_query("insert into admission values('$name','$add',$ph,'$cl',$per,'$pho','$u','$p')");
     if($res==true)
     {
        echo("<h1>Admission form submitted Succ....");
        echo("<a href='Index.php'> BACK </a>");
      } 
?>