<?php
    $name=$_POST["t1"];
    $add=$_POST["t2"];
    $ph=$_POST["t3"];
    $email=$_POST["t4"];
    $comm=$_POST["t5"];
     $con=mysql_connect("localhost","root","");
     if($con==false) 
         die("Error in connection...");
     mysql_select_db("sypro");
    
    $res=mysql_query("insert into contact values('$name','$add',$ph,'$email','$comm')");
     if($res==true)
     {
        header('location:Index.php');
      } 
?>