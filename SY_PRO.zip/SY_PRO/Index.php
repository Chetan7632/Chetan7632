<html>
<head>
    <style>
      #aa{border-style:dotted;
               border-color:red; 
               background-color:yellow;
}
    </style>
</head>
    <body>
         <table border="1" width="90%" align="center">
              <tr>
                <td>
                     <p align='center' id="aa"> Rayat Shikshan Santhas </p>
                    <h1 align="center"> C.D.Jain College of Commerce Shrirampur </h1>
                     <h3> Address: Shrirampur MH.413709.  Phone: 0987654321
                </td>
             </tr>
         </table>
         <table border="1" width="90%" align="center">
              <tr>
                <td> <a href='Index.php'>Home </a> 
                <td> <a href='About.php'>About </a> 
                <td> <a href='Dept.php'>Dept </a> 
                <td> <a href='Syllabous.php'>Syllabous </a> 
                <td> <a href='Sports.php'>Sports </a> 
                <td> <a href='Account.php'>Account Dept </a> 
                <td> <a href='Library.php'>Library </a> 
                <td> <a href='Contact.php'>Contact Us</a> 
               </tr>
         </table>
         <table border="1" width="90%"  height="70%" align="center">
              <tr>
                    <td width="20%" valign="top"> 
                          Photo <br>
                            <img width="100%"  src="images/logo1.jpg"> <br>
              <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15031.979403459529!2d74.6517536!3d19.6275179!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdc8a53ebc13df9%3A0x2f44014aa61d24f4!2sNorthern%20Branch!5e0!3m2!1sen!2sin!4v1675393866773!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
						 
                    <td width="60%" valign="top" bgcolor="pink"> 
                         <h1> Admission Form: </h1>
						 <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdEF-Wsz52TYNWVdiJM_1okhVw4V8c77wNb8_EAOttA8OWU6g/viewform?embedded=true" width="100%" height="800" frameborder="0" marginheight="0" marginwidth="0">Loading�</iframe>
      <td width="20%" valign="top"> 
                        <h1> <img src="images/Arrow1.gif" width="30"> Notice </h1>
						<img src="images/Line1.gif" width="100%"> <br>
                 <marquee direction="up"> 
                       <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice... 
                        <h2>Exam Notice...  
                 </marquee>
                <h1> Admin Login </h1>
                   <form method="post" action="AdminLogin.php">
                      User: 
                       <input type="text" name="t1"> <br>
                      Password: 
                       <input type="password" name="t2"> <br>
                      <input type="submit" value="Login">
                   </form>               
                <h1> Student Login </h1>
                   <form method="post" action="StudLogin.php">
                      User: 
                       <input type="text" name="t1"> <br>
                      Password: 
                       <input type="password" name="t2"> <br>
                      <input type="submit" value="Login">
                   </form>               
              </tr>
         </table>
       <table border="1" width="90%"  bgcolor="gray" height="20%" align="center">
              <tr>
                <td>
                   <h2> Copyright@cdjcollege2023 </h2>
<pre>
Alumni
Introduction
Goal & Objectives
Alumni Membership Form
Alumni Committee
List Of Alumni
Student Login
</pre>
             </tr>
         </table>
               
   </body>
</html>