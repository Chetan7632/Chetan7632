<body>
         <table border="1" width="90%" align="center">
              <tr>
                <td>
                     <p align='center' id="aa"> Rayat Shikshan Santhas </p>
                    <h1 align="center"> C.D.Jain College of Commerce Shrirampur </h1>
                     <h3> Address: Shrirampur MH.413709.  Phone: 0987654321
                </td>
             </tr>
         </table>
         <table border="1" width="90%" align="center">
              <tr>
                <td> <a href='Index.php'>Home </a> 
               </tr>
         </table>
    
<?php
    $u=$_POST["t1"];
	$p=$_POST["t2"];
	
     $con=mysql_connect("localhost","root","");
     if($con==false) 
         die("Error in connection...");
     mysql_select_db("sypro");
    
    $res=mysql_query("select * from admission where username='$u' and password='$p'");
	echo("<table  align='center' border='1'>");
	if($row=mysql_fetch_row($res))
	{
	  echo("<tr> <td>Its ME.. <td>  <img src='$row[5]' width='100%'> </tr>");	  
	  echo("<tr> <td> Name: <td> $row[0] </tr>");
	  echo("<tr> <td> Address: <td> $row[1] </tr>");
	  echo("<tr> <td> Phone Number: <td> $row[2] </tr>");
	  echo("<tr> <td> Class: <td> $row[3] </tr>");
	  echo("<tr> <td> Percentage: <td> $row[4] </tr>");
	}
	else
	{
	  echo("<h1> Invalid User or PAss <a href='Index.php'> Home Page </a>");
	}
?>