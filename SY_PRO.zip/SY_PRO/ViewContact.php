<html>
<head>
    <style>
      #aa{border-style:dotted;
               border-color:red; 
               background-color:yellow;
}
    </style>
</head>
    <body>
         <table border="1" width="90%" align="center">
              <tr>
                <td>
                     <p align='center' id="aa"> Rayat Shikshan Santhas </p>
                    <h1 align="center"> C.D.Jain College of Commerce Shrirampur </h1>
                     <h3> Address: Shrirampur MH.413709.  Phone: 0987654321
                </td>
             </tr>
         </table>
         <table border="1" width="90%" align="center">
              <tr>
                <td> <a href='ViewAdmission.php'>ViewAdmission </a> 
                <td> <a href='ViewContact.php'>View Contact </a> 
                <td> <a href='Index.php'>Logout </a> 
               </tr>
         </table>
   <h1 align='center'> Contact Information </h1>
<?php
       $con=mysql_connect("localhost","root","");
     if($con==false) 
         die("Error in connection...");
     mysql_select_db("sypro");
     $res=mysql_query("select * from contact");
  echo("<table border=1 width='90%' align='center'> ");
  echo("<tr> <th> Name <th> Address <th> Phone <th> EMAIL <th> Commect </tr>");
      while($row=mysql_fetch_array($res))
      {
         echo("<tr> <td> $row[0]");
         echo("<td> $row[1]");
         echo("<td> $row[2]");
         echo("<td> $row[3]");
         echo("<td> $row[4]");
         echo("</tr>");
      }      
     echo("</table>");
?>






