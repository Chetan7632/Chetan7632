<a href='index.php?id=<?php echo $row['id']; ?>'>logout</a>
<?php

header("Location: http://localhost/crud/index.php");
?>