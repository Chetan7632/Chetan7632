 <----------------------  DAIRY MANAGMENT SYSTEM  ------------------------->


Database: `dairy`

-- -----------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS `bratechart` (
  `bfat` double NOT NULL,
  `brate` double NOT NULL,
  PRIMARY KEY (`bfat`));
-- ------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS `collection` (
  `date` date NOT NULL,
  `time` varchar(20) NOT NULL,
  `ssn` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `qty` double NOT NULL,
  `fat` double NOT NULL,
  `rate` double NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`date`,`time`,`ssn`,`type`),
  KEY `ssn` (`ssn`));
-- -----------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS `cratechart` (
  `cfat` double NOT NULL,
  `crate` double NOT NULL,
  PRIMARY KEY (`cfat`));

-- ----------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS `customer` (
  `ssn` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `type` varchar(11) NOT NULL,
  PRIMARY KEY (`ssn`)
);
-- ------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user`));

INSERT INTO `login` (`user`, `password`) VALUES
('chetan','chetan');

-- -------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `viewbill` (
`name` varchar(20)
,`date` date
,`time` varchar(20)
,`ssn` int(11)
,`type` varchar(20)
,`qty` double
,`fat` double
,`rate` double
,`total` double
);
-- --------------------------------------------------------------------------------

DROP TABLE IF EXISTS `viewbill`;
-----------------------------------------------------------------------------------
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewbill` AS select `cu`.`name` AS `name`,`co`.`date` AS `date`,`co`.`time` AS `time`,`co`.`ssn` AS `ssn`,`co`.`type` AS `type`,`co`.`qty` AS `qty`,`co`.`fat` AS `fat`,`co`.`rate` AS `rate`,`co`.`total` AS `total` from (`customer` `cu` join `collection` `co` on((`cu`.`ssn` = `co`.`ssn`)));
-----------------------------------------------------------------------------------
ALTER TABLE `collection`
  ADD CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `customer` (`ssn`) ON DELETE CASCADE ON UPDATE CASCADE;

------------------------------------------------------------------------------------
