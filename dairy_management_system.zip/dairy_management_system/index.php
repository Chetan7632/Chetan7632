<?php
    session_start();
    if (!isset($_SESSION['User'])){
        header("location:login.php");
    }
?>

<html>
    <head>
        <title>DAIRY MANAGMENT SYSTEM</title>
        <link href="../css/public.css" media="all" rel="stylesheet" type="text/css" />
    </head>
    <body bgcolor="#FFFF66">
        <div id="header">
          <center>  <h1>DAIRY MANAGMENT SYSTEM</h1></center>
        </div>
        <div id="main">
            <link href="css/public.css" media="all" rel="stylesheet" type="text/css" />
            <table id="structure">
                <tr>
                    <td id="navigation">
                        <ul>
                            <li class="last"><a href="customer.php">Add New Customer</a></li><br/>
                            <li class="last"><a href="bratechart.php">Add Buffalo Rate Chart</a></li><br/>
                            <li class="last"><a href="cratechart.php">Add Cow Rate Chart</a></li><br/>
                            <li class="last"><a href="collection.php">Daily Milk Collection</a></li><br/>
                            <li class="last"><a href="getallcustomer.php"> Get All Customer Information</a></li><br/>
                            <li class="last"><a href="allcustomerbill.php"> Get All Customer Bill</a></li><br/>
                            <li class="last"><a href="singlecustomerbill.php"> Get Single Customer Bill</a></li><br/>
                            <li class="last"><a href="login.php"> Logout</a></li><br/>
                        </ul>			
                    </td>
                    <td id="page">
                        <img src="img/13.jpg" alt="" width="50%" height="75%"/><img src="img/6.jpg" alt="" width="50%" height="75%"/> 
                         
                    </td>
                </tr>
            </table>
        </div>
        <div id="footer" title = "Designed & Developed by TUSHAR THORAT & CHETAN BADADHE"></div>
    </body>
</html>